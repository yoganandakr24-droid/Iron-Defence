"""Unit tests for Iron Defense Deterministic Risk Engine."""

import pytest
from app.engines.risk_engine import RiskEngine


def test_risk_engine_low_risk():
    # 0 signals -> score 0 -> LOW
    res = RiskEngine.calculate_risk([])
    assert res.risk_score == 0
    assert res.risk_level == "LOW"
    assert len(res.risk_factors) == 0


def test_risk_engine_single_signal_weights():
    # urgency (+10) -> score 10 -> LOW (0-29)
    res_urg = RiskEngine.calculate_risk(["urgency"])
    assert res_urg.risk_score == 10
    assert res_urg.risk_level == "LOW"
    assert res_urg.risk_factors[0].points == 10
    assert res_urg.risk_factors[0].signal == "urgency"

    # suspicious_url (+20) -> score 20 -> LOW (0-29)
    res_url = RiskEngine.calculate_risk(["suspicious_url"])
    assert res_url.risk_score == 20
    assert res_url.risk_level == "LOW"
    assert res_url.risk_factors[0].points == 20

    # known_malicious_reputation (+20)
    res_mal = RiskEngine.calculate_risk(["known_malicious_reputation"])
    assert res_mal.risk_score == 20
    assert res_mal.risk_factors[0].points == 20


def test_risk_engine_medium_risk():
    # suspicious_url (+20) + urgency (+10) = 30 -> MEDIUM (30-59)
    res = RiskEngine.calculate_risk(["suspicious_url", "urgency"])
    assert res.risk_score == 30
    assert res.risk_level == "MEDIUM"

    # credential_request (+20) + authority_impersonation (+10) + threatening_language (+10) = 40 -> MEDIUM
    res2 = RiskEngine.calculate_risk(["credential_request", "authority_impersonation", "threatening_language"])
    assert res2.risk_score == 40
    assert res2.risk_level == "MEDIUM"


def test_risk_engine_high_risk():
    # suspicious_url (+20) + credential_request (+20) + payment_request (+20) = 60 -> HIGH (60-79)
    res = RiskEngine.calculate_risk(["suspicious_url", "credential_request", "payment_request"])
    assert res.risk_score == 60
    assert res.risk_level == "HIGH"


def test_risk_engine_critical_risk_and_capping():
    # suspicious_url (+20) + credential_request (+20) + payment_request (+20) + known_malicious_reputation (+20) = 80 -> CRITICAL
    res = RiskEngine.calculate_risk([
        "suspicious_url",
        "credential_request",
        "payment_request",
        "known_malicious_reputation"
    ])
    assert res.risk_score == 80
    assert res.risk_level == "CRITICAL"

    # All signals combined: 20+20+20+10+10+10+10+20 = 120 -> capped at 100 -> CRITICAL
    all_signals = [
        "suspicious_url",
        "credential_request",
        "payment_request",
        "urgency",
        "authority_impersonation",
        "threatening_language",
        "suspicious_domain_characteristics",
        "known_malicious_reputation"
    ]
    res_all = RiskEngine.calculate_risk(all_signals)
    assert res_all.risk_score == 100
    assert res_all.risk_level == "CRITICAL"
    assert len(res_all.risk_factors) == 8


def test_risk_engine_transparent_factors_with_evidence():
    signals = [
        {"signal": "suspicious_url", "evidence": "Extracted URL: http://phish-site.top"},
        {"signal": "urgency", "evidence": "Phrase found: verify immediately"}
    ]
    res = RiskEngine.calculate_risk(signals)
    assert res.risk_score == 30
    assert res.risk_level == "MEDIUM"
    assert len(res.risk_factors) == 2
    
    fac_url = [f for f in res.risk_factors if f.signal == "suspicious_url"][0]
    assert fac_url.points == 20
    assert fac_url.category == "Suspicious URL"
    assert "http://phish-site.top" in fac_url.description

    fac_urg = [f for f in res.risk_factors if f.signal == "urgency"][0]
    assert fac_urg.points == 10
    assert fac_urg.category == "Urgency"
    assert "verify immediately" in fac_urg.description
