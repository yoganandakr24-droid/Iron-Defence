from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_analyze_suspicious_message():
    payload = {
        "text": "URGENT: Your campus account is suspended! Verify password now at http://bit.ly/login-fake",
        "sender": "+15550199",
        "channel": "sms"
    }
    response = client.post("/api/v1/analyze/message", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "risk" in data
    assert data["risk"]["risk_score"] > 50
    assert data["risk"]["risk_level"] in ["HIGH", "CRITICAL"]
    assert len(data["risk"]["extracted_urls"]) == 1
    assert "http://bit.ly/login-fake" in data["risk"]["extracted_urls"]
    assert len(data["risk"]["factors"]) >= 2

def test_analyze_benign_message():
    payload = {
        "text": "Hey, see you at the library study session at 5pm!",
        "sender": "Alice",
        "channel": "manual"
    }
    response = client.post("/api/v1/analyze/message", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["risk"]["risk_level"] in ["SAFE", "LOW"]
    assert data["risk"]["risk_score"] == 0

def test_analyze_alias_endpoint():
    payload = {
        "text": "URGENT: Verify account at http://192.168.1.1/login",
        "sender": "TestSender",
        "channel": "notification"
    }
    response = client.post("/api/v1/analyze", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["risk"]["risk_level"] in ["HIGH", "CRITICAL"]

def test_analyze_url_endpoint_post():
    payload = {"url": "http://paypa1.com/login"}
    response = client.post("/api/v1/analyze/url", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["url"] == "http://paypa1.com/login"
    assert data["possible_typosquatting_indicators"] is True
    assert data["suspicious"] is True
    assert "score_contribution" in data

def test_analyze_url_endpoint_get():
    response = client.get("/api/v1/analyze/url", params={"url": "https://bit.ly/3xyz"})
    assert response.status_code == 200
    data = response.json()
    assert data["url"] == "https://bit.ly/3xyz"
    assert data["url_shortener_indicators"] is True
    assert data["suspicious"] is False


