import io
import os
import glob
import tempfile
from fastapi.testclient import TestClient
from PIL import Image, ImageDraw

from app.main import app
from app.engines.ocr_engine import OCREngine

client = TestClient(app)

def create_test_image(format_name: str = "PNG", text: str = "SECURITY ALERT: Verify your account at http://phish.xyz/login") -> bytes:
    """Helper to generate in-memory synthetic PNG/JPEG images for testing."""
    img = Image.new("RGB", (600, 150), color=(255, 255, 255))
    draw = ImageDraw.Draw(img)
    draw.text((20, 40), text, fill=(0, 0, 0))
    buffer = io.BytesIO()
    img.save(buffer, format=format_name)
    return buffer.getvalue()


def test_analyze_screenshot_png():
    img_bytes = create_test_image("PNG")
    response = client.post(
        "/api/v1/analyze/screenshot",
        files={"file": ("test_screenshot.png", img_bytes, "image/png")},
        data={"sender": "Campus Security"}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert "ocr" in data
    assert "risk" in data
    assert "extracted_text" in data["ocr"]
    assert "extracted_urls" in data["ocr"]
    assert "ocr_confidence" in data["ocr"]
    assert "ocr_incomplete" in data["ocr"]


def test_analyze_screenshot_jpg():
    img_bytes = create_test_image("JPEG")
    response = client.post(
        "/api/v1/analyze/screenshot",
        files={"file": ("test_screenshot.jpg", img_bytes, "image/jpeg")}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["analysis_source"] == "ocr_threat_engine"


def test_invalid_file_extension():
    response = client.post(
        "/api/v1/analyze/screenshot",
        files={"file": ("malicious.exe", b"binary content", "application/octet-stream")}
    )
    assert response.status_code == 400
    assert "Invalid file extension" in response.json()["detail"]


def test_invalid_image_content():
    response = client.post(
        "/api/v1/analyze/screenshot",
        files={"file": ("fake_image.png", b"Not a real image file", "image/png")}
    )
    assert response.status_code == 400
    assert "not a valid PNG or JPEG" in response.json()["detail"]


def test_file_size_exceeded():
    # 11MB dummy payload
    oversized = b"0" * (11 * 1024 * 1024)
    response = client.post(
        "/api/v1/analyze/screenshot",
        files={"file": ("large_file.png", oversized, "image/png")}
    )
    assert response.status_code == 400
    assert "exceeds maximum allowed limit" in response.json()["detail"]


def test_temporary_file_cleanup():
    temp_dir = tempfile.gettempdir()
    before_files = set(glob.glob(os.path.join(temp_dir, "*")))
    
    img_bytes = create_test_image("PNG")
    response = client.post(
        "/api/v1/analyze/screenshot",
        files={"file": ("cleanup_test.png", img_bytes, "image/png")}
    )
    assert response.status_code == 200
    
    after_files = set(glob.glob(os.path.join(temp_dir, "*")))
    # Verify no persistent temporary files were leaked in system temp
    new_files = [f for f in (after_files - before_files) if "tmp" in f.lower() or "cleanup" in f.lower()]
    assert len(new_files) == 0


def test_blank_image_incomplete_indicator():
    # Blank image with no text
    img = Image.new("RGB", (200, 200), color=(255, 255, 255))
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    
    response = client.post(
        "/api/v1/analyze/screenshot",
        files={"file": ("blank.png", buffer.getvalue(), "image/png")}
    )
    assert response.status_code == 200
    data = response.json()
    assert data["ocr"]["ocr_incomplete"] is True
    assert data["ocr"]["ocr_warning"] is not None
    assert "No text could be extracted" in data["ocr"]["ocr_warning"] or "confidence" in data["ocr"]["ocr_warning"].lower()
