import pytest
from app.engines.url_engine import URLEngine

def test_url_extraction_basic():
    url = "https://sub.example.co.uk:8080/path/to/page?user=john&ref=123"
    result = URLEngine.analyze_url(url)
    
    assert result["url"] == url
    assert result["scheme"] == "https"
    assert result["hostname"] == "sub.example.co.uk"
    assert result["registered_domain"] == "example.co.uk"
    assert result["port"] == 8080
    assert result["path"] == "/path/to/page"
    assert result["query_parameters"] == {"user": "john", "ref": "123"}
    assert result["subdomain_count"] == 1
    assert result["url_length"] == len(url)
    assert result["presence_of_ip_address"] is False
    assert result["suspicious"] is False
    assert result["score_contribution"] == 0

def test_ip_address_detection():
    url = "http://192.168.1.1:3000/verify_account"
    result = URLEngine.analyze_url(url)
    
    assert result["presence_of_ip_address"] is True
    assert result["hostname"] == "192.168.1.1"
    assert result["registered_domain"] == "192.168.1.1"
    assert result["port"] == 3000
    assert result["hostname_domain_mismatch_indicators"] is True  # non-standard port & http sensitive path
    assert result["suspicious"] is True
    assert result["score_contribution"] >= 50

def test_single_heuristic_does_not_declare_malicious():
    # Only URL shortener heuristic present
    url = "https://bit.ly/3xyz"
    result = URLEngine.analyze_url(url)
    
    assert result["url_shortener_indicators"] is True
    assert len(result["signals"]) == 1
    assert result["score_contribution"] == 20
    # Rule enforcement: single heuristic must NOT declare suspicious/malicious
    assert result["suspicious"] is False

def test_single_suspicious_tld_not_malicious():
    url = "https://mywebsite.xyz/blog"
    result = URLEngine.analyze_url(url)
    
    assert result["suspicious_tld"] is True
    assert len(result["signals"]) == 1
    assert result["suspicious"] is False
    assert result["score_contribution"] > 0

def test_typosquatting_detection():
    url = "http://paypa1.com/login"
    result = URLEngine.analyze_url(url)
    
    assert result["possible_typosquatting_indicators"] is True
    # Has typosquatting + HTTP sensitive path (mismatch indicator) => multiple heuristics
    assert result["hostname_domain_mismatch_indicators"] is True
    assert result["suspicious"] is True
    assert result["score_contribution"] >= 65

def test_domain_mismatch_and_excessive_subdomains():
    url = "http://login.paypal.com.account-update.xyz/verify?session=123"
    result = URLEngine.analyze_url(url)
    
    assert result["subdomain_count"] >= 3
    assert result["excessive_subdomains"] is True
    assert result["suspicious_tld"] is True
    assert result["hostname_domain_mismatch_indicators"] is True
    assert result["suspicious"] is True
    assert len(result["signals"]) >= 3

def test_suspicious_characters_and_encoding():
    url = "http://google.com@attacker.com/path//login?ref=%2520test"
    result = URLEngine.analyze_url(url)
    
    assert result["suspicious_characters"] is True
    assert result["url_encoding"] is True
    assert result["suspicious"] is True

def test_empty_url_input():
    result = URLEngine.analyze_url("")
    assert result["url"] == ""
    assert result["suspicious"] is False
    assert result["score_contribution"] == 0
    assert result["signals"] == []
