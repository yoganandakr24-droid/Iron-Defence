import os
import io
import re
import tempfile
from typing import Optional, List, Tuple
from datetime import datetime, timezone
from PIL import Image
import pytesseract

from app.core.config import settings
from app.models.analyze import (
    AnalyzeScreenshotResponse,
    OCRResult,
    AnalyzeMessageRequest,
    ThreatFactor,
)
from app.engines.message_engine import MessageEngine


class OCREngine:
    """OCR & Screenshot Threat Analysis Engine.
    Handles image validation, temporary storage, OCR extraction, URL parsing,
    confidence scoring, incomplete state detection, and threat report generation.
    """

    @staticmethod
    def _clean_ocr_urls(text: str) -> str:
        """Fix common OCR artifacts in URLs, such as space around slashes or colons."""
        if not text:
            return ""
        # Fix http / https spacing artifacts
        cleaned = re.sub(r'https?\s*:\s*/\s*/\s*', lambda m: m.group(0).replace(' ', ''), text, flags=re.IGNORECASE)
        # Fix spaces around dots in domains e.g. bit . ly -> bit.ly
        cleaned = re.sub(r'([a-zA-Z0-9-]+)\s*\.\s*(com|org|net|edu|gov|io|co|me|bit|tinyurl|t\.co|goo\.gl)\b', r'\1.\2', cleaned, flags=re.IGNORECASE)
        return cleaned

    @classmethod
    def extract_ocr_data(cls, image_path: str) -> Tuple[str, List[str], float, bool, Optional[str]]:
        """Extract text, URLs, confidence, incomplete flag, and warning from image file using pytesseract."""
        extracted_text = ""
        confidence_scores: List[float] = []
        ocr_warning: Optional[str] = None
        
        try:
            with Image.open(image_path) as img:
                img_rgb = img.convert('RGB')
                
                # Extract word-level confidence data if available
                try:
                    data = pytesseract.image_to_data(img_rgb, output_type=pytesseract.Output.DICT)
                    if 'text' in data and 'conf' in data:
                        for i in range(len(data['text'])):
                            word = data['text'][i].strip()
                            conf = int(data['conf'][i])
                            if word and conf >= 0:
                                confidence_scores.append(conf)
                except Exception:
                    pass

                # Extract string text
                try:
                    extracted_text = pytesseract.image_to_string(img_rgb).strip()
                except pytesseract.TesseractNotFoundError:
                    ocr_warning = "Tesseract OCR executable not detected on host system. Fallback processing active."
                except Exception as e:
                    ocr_warning = f"OCR engine processing warning: {str(e)}"
                    
        except Exception as e:
            ocr_warning = f"Failed to open or parse screenshot image: {str(e)}"

        cleaned_text = cls._clean_ocr_urls(extracted_text)
        extracted_urls = MessageEngine.extract_urls(cleaned_text if cleaned_text else extracted_text)

        # Calculate OCR confidence (0.0 to 1.0)
        if confidence_scores:
            avg_conf = (sum(confidence_scores) / len(confidence_scores)) / 100.0
            ocr_confidence = round(min(1.0, max(0.0, avg_conf)), 2)
        elif extracted_text and not ocr_warning:
            ocr_confidence = 0.75  # Default confidence for successfully extracted text without word breakdown
        elif extracted_text and ocr_warning:
            ocr_confidence = 0.40
        else:
            ocr_confidence = 0.0

        # Determine incomplete OCR state
        ocr_incomplete = False
        if not extracted_text or len(extracted_text.strip()) == 0:
            ocr_incomplete = True
            empty_msg = "No text could be extracted from the uploaded image. The image may be blurry, low contrast, or contain no text."

            ocr_warning = f"{empty_msg} ({ocr_warning})" if ocr_warning else empty_msg
        elif ocr_confidence < 0.60:
            ocr_incomplete = True
            conf_msg = f"OCR extraction confidence is low ({int(ocr_confidence * 100)}%). Some text or URLs may be incomplete or unreadable."
            ocr_warning = f"{conf_msg} ({ocr_warning})" if ocr_warning else conf_msg


        return cleaned_text if cleaned_text else extracted_text, extracted_urls, ocr_confidence, ocr_incomplete, ocr_warning

    @classmethod
    def process_screenshot(cls, file_bytes: bytes, filename: str, sender: Optional[str] = None) -> AnalyzeScreenshotResponse:
        """Main entry point for screenshot analysis workflow.
        1. Validate file format & size
        2. Store temporarily
        3. OCR text & URL extraction
        4. Delete temporary file immediately
        5. Pass to Threat Engine & generate threat report
        """
        if len(file_bytes) > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
            raise ValueError(f"File size exceeds maximum allowed limit of {settings.MAX_UPLOAD_SIZE_MB} MB")

        ext = os.path.splitext(filename)[1].lower() if filename else ".png"
        if ext not in settings.ALLOWED_IMAGE_EXTENSIONS:
            raise ValueError(f"Invalid file extension '{ext}'. Allowed extensions: {', '.join(settings.ALLOWED_IMAGE_EXTENSIONS)}")

        # Verify PIL image valid
        try:
            with Image.open(io.BytesIO(file_bytes)) as test_img:
                if test_img.format not in ["PNG", "JPEG"]:
                    raise ValueError(f"Unsupported image format '{test_img.format}'. Only PNG and JPEG are accepted.")
        except Exception as e:
            if isinstance(e, ValueError):
                raise
            raise ValueError("Uploaded file is not a valid PNG or JPEG image.")

        temp_file_path: Optional[str] = None
        try:
            # 3. Store upload temporarily
            with tempfile.NamedTemporaryFile(delete=False, suffix=ext) as tmp:
                tmp.write(file_bytes)
                temp_file_path = tmp.name

            # 4. Extract text using OCR & Extract URLs using URL parsing
            text, urls, confidence, incomplete, warning = cls.extract_ocr_data(temp_file_path)

        finally:
            # 6. Do not permanently store uploaded screenshots by default -> Delete temp file immediately
            if temp_file_path and os.path.exists(temp_file_path):
                try:
                    os.unlink(temp_file_path)
                except Exception:
                    pass

        # Construct OCR Result model
        ocr_result = OCRResult(
            extracted_text=text,
            extracted_urls=urls,
            ocr_confidence=confidence,
            ocr_incomplete=incomplete,
            ocr_warning=warning,
        )

        # 5. Send text and URLs to threat engine
        analysis_text = text if text.strip() else "[UNREADABLE SCREENSHOT: NO TEXT EXTRACTED]"
        msg_request = AnalyzeMessageRequest(
            text=analysis_text,
            sender=sender,
            channel="screenshot",
        )
        msg_response = MessageEngine.analyze(msg_request)
        risk = msg_response.risk

        # Ensure extracted URLs in risk response include all OCR-parsed URLs
        combined_urls = list(dict.fromkeys(risk.extracted_urls + urls))
        risk.extracted_urls = combined_urls

        # Add OCR warning factors to risk breakdown if incomplete
        if incomplete:
            risk.factors.append(
                ThreatFactor(
                    category="ocr_quality_warning",
                    severity="HIGH" if not text.strip() else "MEDIUM",
                    description=warning or "OCR extraction confidence is incomplete. Manual verification recommended.",
                )
            )

        return AnalyzeScreenshotResponse(
            success=True,
            analyzed_at=datetime.now(timezone.utc).isoformat(),
            ocr=ocr_result,
            risk=risk,
            analysis_source="ocr_threat_engine",
        )
