import re
from datetime import datetime, timezone
from typing import Any, Dict, List
from app.engines.risk_engine import RiskEngine
from app.models.analyze import (
    AnalyzeMessageRequest,
    AnalyzeMessageResponse,
    RiskDetails,
    ThreatFactor,
)

# Regular expression to extract HTTP/HTTPS and short URLs with paths
URL_REGEX = re.compile(
    r"https?://[^\s><\"']+|"
    r"(?:[a-zA-Z0-9-]+\.)+(?:com|org|net|edu|gov|io|co|me|bit|tinyurl|t\.co|goo\.gl)[^\s><\"']*",
    re.IGNORECASE,
)

# Signal detection keyword rules
URGENCY_KEYWORDS = [
    "urgent", "immediately", "account suspended", "action required",
    "verify now", "security alert", "unauthorized login", "password reset",
    "expired", "account blocked", "click here", "claim prize", "winner",
    "immediate action", "act fast", "limited time"
]

CREDENTIAL_KEYWORDS = [
    "password", "pin", "otp", "ssn", "student id", "bank", "credit card",
    "login", "verification code", "credentials", "passcode", "security code"
]

PAYMENT_KEYWORDS = [
    "payment", "wire transfer", "gift card", "fee", "money", "invoice",
    "pay now", "dollars", "bitcoin", "crypto", "zelle", "venmo", "transfer money",
    "refund processing"
]

AUTHORITY_KEYWORDS = [
    "campus admin", "security department", "helpdesk", "bank official",
    "support desk", "administrator", "dean", "officer", "it department",
    "it support", "system admin", "campus security"
]

THREATENING_KEYWORDS = [
    "terminate", "suspend", "disable", "legal action", "arrest", "police",
    "law enforcement", "penalty", "fine", "locked permanently", "deactivated",
    "prosecuted"
]

SUSPICIOUS_TLDS = [".xyz", ".top", ".info", ".tk", ".ml", ".cf", ".gq", ".zip", ".bit.ly", ".tinyurl.com"]
IP_URL_REGEX = re.compile(r"https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")
MALICIOUS_INDICATORS = ["fake-login", "phish", "scam-test", "malicious", "bad-site", "blacklisted"]


class MessageEngine:
    """Message engine integrating signal detection with the Iron Defense Risk Engine."""

    @staticmethod
    def extract_urls(text: str) -> List[str]:
        return list(set(URL_REGEX.findall(text)))

    @classmethod
    def analyze(cls, request: AnalyzeMessageRequest) -> AnalyzeMessageResponse:
        text_lower = request.text.lower()
        extracted_urls = cls.extract_urls(request.text)
        detected_signals: List[Dict[str, Any]] = []

        # 1. Suspicious URL signal (+20)
        if extracted_urls:
            detected_signals.append({
                "signal": "suspicious_url",
                "evidence": f"Extracted URL: {extracted_urls[0]}"
            })

        # 2. Credential Request signal (+20)
        found_credentials = [kw for kw in CREDENTIAL_KEYWORDS if kw in text_lower]
        if found_credentials:
            detected_signals.append({
                "signal": "credential_request",
                "evidence": f"Keywords found: {', '.join(found_credentials[:3])}"
            })

        # 3. Payment Request signal (+20)
        found_payments = [kw for kw in PAYMENT_KEYWORDS if kw in text_lower]
        if found_payments:
            detected_signals.append({
                "signal": "payment_request",
                "evidence": f"Keywords found: {', '.join(found_payments[:3])}"
            })

        # 4. Urgency signal (+10)
        found_urgency = [kw for kw in URGENCY_KEYWORDS if kw in text_lower]
        if found_urgency:
            detected_signals.append({
                "signal": "urgency",
                "evidence": f"Pressure phrases found: {', '.join(found_urgency[:3])}"
            })

        # 5. Authority Impersonation signal (+10)
        found_authority = [kw for kw in AUTHORITY_KEYWORDS if kw in text_lower]
        sender_lower = (request.sender or "").lower()
        if found_authority or any(kw in sender_lower for kw in ["admin", "security", "support", "bank"]):
            detected_signals.append({
                "signal": "authority_impersonation",
                "evidence": f"Impersonation indicators found in sender/body: {request.sender or ', '.join(found_authority[:2])}"
            })

        # 6. Threatening Language signal (+10)
        found_threats = [kw for kw in THREATENING_KEYWORDS if kw in text_lower]
        if found_threats:
            detected_signals.append({
                "signal": "threatening_language",
                "evidence": f"Coercive terms found: {', '.join(found_threats[:3])}"
            })

        # 7. Suspicious Domain Characteristics (+10)
        has_suspicious_domain = False
        if extracted_urls:
            for url in extracted_urls:
                url_low = url.lower()
                if IP_URL_REGEX.search(url_low) or any(tld in url_low for tld in SUSPICIOUS_TLDS):
                    has_suspicious_domain = True
                    break
        if has_suspicious_domain:
            detected_signals.append({
                "signal": "suspicious_domain_characteristics",
                "evidence": f"Domain features IP/suspicious TLD: {extracted_urls[0]}"
            })

        # 8. Known Malicious Reputation (+20)
        has_known_malicious = False
        if extracted_urls:
            if any(ind in url.lower() for url in extracted_urls for ind in MALICIOUS_INDICATORS):
                has_known_malicious = True
        if has_known_malicious:
            detected_signals.append({
                "signal": "known_malicious_reputation",
                "evidence": "Confirmed malicious indicator in URL/domain reputation feed"
            })

        # Calculate final prototype risk score deterministically via Risk Engine
        risk_output = RiskEngine.calculate_risk(detected_signals)

        # Convert RiskEngine factors to model ThreatFactor list
        threat_factors: List[ThreatFactor] = [
            ThreatFactor(
                category=f.category,
                severity=f.severity,
                description=f.description,
                points=f.points,
                signal=f.signal,
                evidence=f.evidence,
            )
            for f in risk_output.risk_factors
        ]

        # Formulate summary and recommended actions based on prototype risk score
        risk_level = risk_output.risk_level
        score = risk_output.risk_score

        if risk_level == "CRITICAL":
            summary = f"Critical prototype risk score ({score}/100). High severity social engineering or phishing threat."
            advice = "Do NOT click links, reply, or share credentials. Immediately report message to campus security."
        elif risk_level == "HIGH":
            summary = f"High prototype risk score ({score}/100). Multiple suspicious risk factors identified."
            advice = "Verify the identity of the sender through official campus channels before taking action."
        elif risk_level == "MEDIUM":
            summary = f"Medium prototype risk score ({score}/100). Potential social engineering indicators observed."
            advice = "Proceed with caution. Carefully check links and request authenticity."
        else:
            summary = f"Low prototype risk score ({score}/100). No significant threat factors detected."
            advice = "Message appears normal. Always maintain standard cybersecurity awareness."

        risk_details = RiskDetails(
            risk_score=score,
            risk_level=risk_level,
            summary=summary,
            risk_factors=threat_factors,
            factors=threat_factors,
            recommended_action=advice,
            extracted_urls=extracted_urls,
        )

        return AnalyzeMessageResponse(
            success=True,
            analyzed_at=datetime.now(timezone.utc).isoformat(),
            risk=risk_details,
            analysis_source="risk_engine",
        )
