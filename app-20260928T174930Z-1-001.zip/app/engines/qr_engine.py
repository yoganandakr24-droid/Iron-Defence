"""QR Code Security Analysis Engine for Iron Defense.

Decodes QR images, extracts raw payload strings, classifies payload types (URL vs. Plain Text),
executes URL/text analysis pipelines, invokes AI contextual reasoning when required,
and produces comprehensive explainable threat reports.
"""

import base64
import io
import re
import urllib.parse
from datetime import datetime, timezone
from typing import Dict, Any, Optional, Tuple, List

import cv2
import numpy as np
from PIL import Image

from app.engines.ai_engine import AIEngine
from app.engines.message_engine import MessageEngine, URL_REGEX
from app.engines.risk_engine import RiskEngine
from app.engines.url_engine import URLEngine
from app.models.analyze import (
    AnalyzeMessageRequest,
    AnalyzeQRResponse,
    SecuritySignal,
)

class QREngine:
    """QR Code Analysis Engine implementing end-to-end security analysis flow."""

    @staticmethod
    def decode_qr_image(image_bytes: bytes) -> Tuple[bool, str, Optional[str]]:
        """Decode QR code matrix from raw image bytes using multi-stage OpenCV preprocessing."""
        if not image_bytes:
            return False, "", "Empty image byte data provided."

        try:
            # 1. Decode raw image bytes to OpenCV matrix
            nparr = np.frombuffer(image_bytes, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

            if img is None:
                # Fallback: open via PIL and convert to OpenCV numpy array
                try:
                    pil_img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
                    img = cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR)
                except Exception as pil_err:
                    return False, "", f"Failed to parse image matrix: {str(pil_err)}"

            detector = cv2.QRCodeDetector()

            # Stage 1: Standard color decode
            data, bbox, _ = detector.detectAndDecode(img)
            if data and data.strip():
                return True, data.strip(), None

            # Stage 2: Grayscale decode
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            data, bbox, _ = detector.detectAndDecode(gray)
            if data and data.strip():
                return True, data.strip(), None

            # Stage 3: Thresholding & contrast enhancement
            thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
            data, bbox, _ = detector.detectAndDecode(thresh)
            if data and data.strip():
                return True, data.strip(), None

            # Stage 4: Multi-QR detection
            retval, decoded_info, points, _ = detector.detectAndDecodeMulti(img)
            if retval and decoded_info:
                for info in decoded_info:
                    if info and info.strip():
                        return True, info.strip(), None

            return False, "", "No QR code matrix could be detected in the provided image."

        except Exception as e:
            return False, "", f"QR decoder processing error: {str(e)}"

    @staticmethod
    def determine_is_url(payload: str) -> Tuple[bool, Optional[str]]:
        """Determine whether payload is a URL and extract/normalize destination URL."""
        if not payload:
            return False, None

        payload_str = payload.strip()
        payload_lower = payload_str.lower()

        # Direct HTTP/HTTPS scheme
        if payload_lower.startswith("http://") or payload_lower.startswith("https://"):
            return True, payload_str

        # Other schemes like ftp://, hxxp://
        if re.match(r"^(?:[a-zA-Z0-9+.-]+)://", payload_str):
            return True, payload_str

        # Domain pattern match (e.g. www.paypal.com/login, bit.ly/3xyz)
        url_match = URL_REGEX.search(payload_str)
        if url_match:
            matched_text = url_match.group(0)
            # If matched text covers most of payload or starts payload
            if len(matched_text) >= 0.7 * len(payload_str) or payload_str.startswith(matched_text):
                norm_url = matched_text if matched_text.lower().startswith("http") else f"http://{matched_text}"
                return True, norm_url

        # Check urlparse heuristic for domain with dot
        if "." in payload_str and not " " in payload_str and not "\n" in payload_str:
            parsed = urllib.parse.urlparse(f"http://{payload_str}")
            if parsed.netloc and "." in parsed.netloc:
                parts = parsed.netloc.split(".")
                if len(parts) >= 2 and len(parts[-1]) >= 2:
                    return True, f"http://{payload_str}"

        return False, None

    @classmethod
    def analyze(
        cls,
        image_bytes: Optional[bytes] = None,
        image_base64: Optional[str] = None,
        qr_text: Optional[str] = None
    ) -> AnalyzeQRResponse:
        """Run complete QR code security analysis flow."""
        payload = ""
        is_decoded = False
        decode_error = None

        # 1. Extract raw payload string
        if qr_text and qr_text.strip():
            payload = qr_text.strip()
            is_decoded = True
        elif image_base64 and image_base64.strip():
            try:
                # Strip data URI prefix if present
                clean_b64 = image_base64
                if "," in clean_b64:
                    clean_b64 = clean_b64.split(",", 1)[1]
                raw_bytes = base64.b64decode(clean_b64)
                is_decoded, payload, decode_error = cls.decode_qr_image(raw_bytes)
            except Exception as b64_err:
                decode_error = f"Invalid base64 image data: {str(b64_err)}"
        elif image_bytes:
            is_decoded, payload, decode_error = cls.decode_qr_image(image_bytes)
        else:
            raise ValueError("No QR image file, base64 data, or QR text payload provided.")

        if not is_decoded or not payload:
            err_msg = decode_error or "Unable to extract payload from QR image."
            # Return response indicating failed decoding with CRITICAL or HIGH risk warning if image is unreadable
            return AnalyzeQRResponse(
                success=False,
                analyzed_at=datetime.now(timezone.utc).isoformat(),
                qr_payload="[UNREADABLE QR CODE]",
                is_url=False,
                destination_url=None,
                security_signals=[
                    SecuritySignal(
                        category="qr_decoder_failure",
                        severity="HIGH",
                        description=err_msg,
                        source="qr_engine"
                    )
                ],
                risk_score=50,
                risk_level="HIGH",
                attack_type="Unreadable or Corrupted QR Code",
                explanation=f"QR Decoder failure: {err_msg}",
                recommended_action="Do NOT scan or trust unreadable/corrupted QR codes. Re-upload a clearer image.",
                ai_analysis_performed=False,
                analysis_source="qr_threat_engine"
            )

        # 2. Determine whether payload is a URL
        is_url, destination_url = cls.determine_is_url(payload)

        # 3. URL analysis / Message analysis
        url_analysis: Optional[Dict[str, Any]] = None
        message_analysis: Optional[Dict[str, Any]] = None

        if is_url and destination_url:
            url_analysis = URLEngine.analyze_url(destination_url)
        else:
            # Analyze plain text payload
            msg_req = AnalyzeMessageRequest(text=payload, channel="qr_code")
            msg_resp = MessageEngine.analyze(msg_req)
            message_analysis = msg_resp.model_dump()
            
            # If plain text contains embedded URLs, analyze the first embedded URL as well
            if msg_resp.risk.extracted_urls:
                first_embedded = msg_resp.risk.extracted_urls[0]
                url_analysis = URLEngine.analyze_url(first_embedded)

        # 4. AI analysis if text/context requires it
        url_signals = url_analysis.get("signals", []) if url_analysis else []
        ai_res = AIEngine.analyze_qr_payload(
            payload=payload,
            is_url=is_url,
            url_signals=url_signals
        )

        # 5. Risk engine composite evaluation
        risk_eval = RiskEngine.evaluate_qr_risk(
            payload=payload,
            is_url=is_url,
            destination_url=destination_url,
            url_analysis=url_analysis,
            message_analysis=message_analysis,
            ai_analysis=ai_res
        )

        # 6. Formulate threat report response
        return AnalyzeQRResponse(
            success=True,
            analyzed_at=datetime.now(timezone.utc).isoformat(),
            qr_payload=payload,
            is_url=is_url,
            destination_url=destination_url,
            security_signals=risk_eval["security_signals"],
            risk_score=risk_eval["risk_score"],
            risk_level=risk_eval["risk_level"],
            attack_type=risk_eval["attack_type"],
            explanation=risk_eval["explanation"],
            recommended_action=risk_eval["recommended_action"],
            ai_analysis_performed=ai_res.get("ai_analysis_performed", False),
            analysis_source="qr_threat_engine",
            risk=risk_eval.get("risk")
        )
