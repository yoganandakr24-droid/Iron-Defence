"""AI Threat Analysis Engine for Iron Defense.

Provides AI-driven intent classification, attack pattern recognition, and fallback analysis
when payload text or QR context requires deeper contextual reasoning.
"""

from typing import Dict, Any, List, Optional
import re

class AIEngine:
    @staticmethod
    def analyze_payload(text: str) -> Dict[str, Any]:
        """Analyze raw message text or payload using AI threat detection rules."""
        text_lower = (text or "").lower()
        
        # High urgency or credential signals
        requires_ai = any(kw in text_lower for kw in [
            "urgent", "verify", "password", "suspended", "security alert",
            "account", "bank", "ssn", "login", "pin", "claim", "winner"
        ])
        
        if requires_ai:
            return {
                "ai_analysis": "AI context analysis identified potential social engineering or credential harvesting intent.",
                "confidence": 0.85,
                "suggested_attack_type": "Social Engineering / Phishing",
                "risk_bonus": 15
            }
        
        return {
            "ai_analysis": "Standard payload structure analyzed; no complex AI threat indicators flagged.",
            "confidence": 0.90,
            "suggested_attack_type": "None / Safe",
            "risk_bonus": 0
        }

    @staticmethod
    def should_trigger_ai(payload: str, is_url: bool, url_signals: List[Dict[str, Any]] = None) -> bool:
        """Determine whether payload text or URL context requires AI deep analysis."""
        if not payload:
            return False
            
        payload_lower = payload.lower()
        
        # If payload is plain text with suspicious keywords or request for credentials/action
        ai_trigger_keywords = [
            "urgent", "immediately", "verify", "password", "suspended", "action required",
            "security", "login", "credential", "bank", "otp", "pin", "ssn", "winner",
            "claim", "transfer", "wifi:", "smsto:", "mailto:"
        ]
        
        if any(kw in payload_lower for kw in ai_trigger_keywords):
            return True

        # If payload is a URL and has ambiguous shortener or multiple suspicious signals
        if is_url:
            if url_signals and len(url_signals) >= 1:
                return True
            if any(s in payload_lower for s in ["bit.ly", "tinyurl.com", "t.co", "cutt.ly", "is.gd", "goo.gl"]):
                return True

        return False

    @classmethod
    def analyze_qr_payload(
        cls, payload: str, is_url: bool, url_signals: List[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Perform AI contextual analysis on a QR code payload."""
        should_run = cls.should_trigger_ai(payload, is_url, url_signals)
        if not should_run:
            return {
                "ai_analysis_performed": False,
                "attack_type": None,
                "risk_adjustment": 0,
                "ai_explanation": None,
                "signals": []
            }

        payload_lower = payload.lower()
        signals = []
        risk_adjustment = 15
        attack_type = "Quishing (QR Phishing)" if is_url else "Social Engineering Fraud"
        explanation_parts = []

        if is_url:
            explanation_parts.append("AI Threat Analysis evaluated the QR URL context.")
            if any(kw in payload_lower for kw in ["login", "verify", "signin", "account", "secure", "bank"]):
                attack_type = "Quishing (QR Credential Harvesting)"
                risk_adjustment += 15
                signals.append({
                    "category": "ai_credential_intent",
                    "severity": "HIGH",
                    "description": "AI detected credential harvesting intent targeting user authentication",
                    "source": "ai_engine"
                })
            elif any(kw in payload_lower for kw in ["bit.ly", "tinyurl.com", "t.co", "cutt.ly", "is.gd"]):
                attack_type = "Quishing (QR Shortened URL Masking)"
                risk_adjustment += 10
                signals.append({
                    "category": "ai_shortener_masking",
                    "severity": "MEDIUM",
                    "description": "AI identified shortened URL designed to obscure final landing domain",
                    "source": "ai_engine"
                })
        else:
            explanation_parts.append("AI Threat Analysis evaluated the QR plain text payload.")
            if any(kw in payload_lower for kw in ["password", "pin", "otp", "ssn", "credentials", "bank"]):
                attack_type = "Plain Text Credential Theft"
                risk_adjustment += 25
                signals.append({
                    "category": "ai_plain_text_credential_theft",
                    "severity": "CRITICAL",
                    "description": "AI detected explicit request for sensitive authentication credentials in QR text payload",
                    "source": "ai_engine"
                })
            elif "wifi:" in payload_lower:
                attack_type = "Suspicious Wi-Fi Configuration Trap"
                risk_adjustment += 15
                signals.append({
                    "category": "ai_wifi_trap",
                    "severity": "MEDIUM",
                    "description": "AI flagged Wi-Fi configuration payload requiring network verification",
                    "source": "ai_engine"
                })

        return {
            "ai_analysis_performed": True,
            "attack_type": attack_type,
            "risk_adjustment": risk_adjustment,
            "ai_explanation": " ".join(explanation_parts),
            "signals": signals
        }
