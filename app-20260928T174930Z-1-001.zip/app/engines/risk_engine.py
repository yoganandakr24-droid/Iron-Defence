"""Explainable Risk Score Engine for Iron Defense.

Calculates final prototype risk score deterministically from classifications and evidence
provided by LLM, URL intelligence, or heuristic scanners.

Signal Weights:
  - Suspicious URL: +20
  - Credential request: +20
  - Payment request: +20
  - Urgency: +10
  - Authority impersonation: +10
  - Threatening language: +10
  - Suspicious domain characteristics: +10
  - Known malicious reputation: +20

Score Range & Capping: 0 to 100 (capped at 100)

Risk Levels:
  - 0 - 29  = LOW
  - 30 - 59 = MEDIUM
  - 60 - 79 = HIGH
  - 80 - 100 = CRITICAL
"""

from typing import Dict, Any, List, Optional, Union
from dataclasses import dataclass, field
from app.models.analyze import SecuritySignal, RiskDetails, ThreatFactor


@dataclass
class RiskCalculationResult:
    """Result object returned by calculate_risk."""
    risk_score: int = 0
    risk_level: str = "LOW"
    risk_factors: List[ThreatFactor] = field(default_factory=list)


class RiskEngine:
    """Deterministic Risk Engine for Iron Defense."""

    @staticmethod
    def compute_composite_risk(url_score: int = 0, ai_score: int = 0, heuristic_score: int = 0) -> int:
        """Compute composite risk score enforcing deterministic backend control."""
        composite = int(0.4 * url_score + 0.4 * heuristic_score + 0.2 * ai_score)
        return min(100, max(0, composite))

    # Signal definitions mapping signal keys to category title, severity, default description, and points added
    SIGNAL_REGISTRY: Dict[str, Dict[str, Any]] = {
        "suspicious_url": {
            "category": "Suspicious URL",
            "severity": "HIGH",
            "description": "Message contains a suspicious or embedded URL",
            "points": 20,
        },
        "credential_request": {
            "category": "Credential Request",
            "severity": "HIGH",
            "description": "Message requests sensitive credentials or authentication data",
            "points": 20,
        },
        "payment_request": {
            "category": "Payment Request",
            "severity": "HIGH",
            "description": "Message involves payment, wire transfer, gift card, or financial request",
            "points": 20,
        },
        "urgency": {
            "category": "Urgency",
            "severity": "MEDIUM",
            "description": "Message uses high-pressure urgency language",
            "points": 10,
        },
        "authority_impersonation": {
            "category": "Authority Impersonation",
            "severity": "MEDIUM",
            "description": "Message impersonates an authority figure or trusted organization",
            "points": 10,
        },
        "threatening_language": {
            "category": "Threatening Language",
            "severity": "MEDIUM",
            "description": "Message contains coercive, intimidating, or threatening language",
            "points": 10,
        },
        "suspicious_domain_characteristics": {
            "category": "Suspicious Domain Characteristics",
            "severity": "MEDIUM",
            "description": "URL domain uses IP address, typosquatting, or suspicious TLD",
            "points": 10,
        },
        "known_malicious_reputation": {
            "category": "Known Malicious Reputation",
            "severity": "CRITICAL",
            "description": "External threat intelligence confirms known malicious reputation",
            "points": 20,
        },
    }

    @staticmethod
    def get_risk_level(score: int) -> str:
        """Map prototype risk score to categorical risk level.
        
        0 - 29  = LOW
        30 - 59 = MEDIUM
        60 - 79 = HIGH
        80 - 100 = CRITICAL
        """
        if score >= 80:
            return "CRITICAL"
        elif score >= 60:
            return "HIGH"
        elif score >= 30:
            return "MEDIUM"
        else:
            return "LOW"

    @classmethod
    def calculate_risk(cls, detected_signals: List[Union[str, Dict[str, Any]]]) -> RiskCalculationResult:
        """Calculate prototype risk score deterministically from detected signals/classifications.

        Args:
            detected_signals: List of signal keys (str) or signal dicts containing optional
                              evidence details or custom overrides.

        Returns:
            RiskCalculationResult with risk_score, risk_level, and risk_factors.
        """
        risk_factors: List[ThreatFactor] = []
        total_score = 0
        processed_signals = set()

        for sig in detected_signals:
            if isinstance(sig, str):
                signal_key = sig
                evidence = None
                custom_points = None
            elif isinstance(sig, dict):
                signal_key = sig.get("signal") or sig.get("key") or sig.get("category", "unknown")
                evidence = sig.get("evidence")
                custom_points = sig.get("points")
            else:
                continue

            if not signal_key or signal_key in processed_signals:
                continue

            processed_signals.add(signal_key)

            registry_entry = cls.SIGNAL_REGISTRY.get(signal_key, {
                "category": signal_key.replace("_", " ").title(),
                "severity": "MEDIUM",
                "description": f"Detected signal: {signal_key}",
                "points": 10
            })

            points = custom_points if custom_points is not None else registry_entry["points"]
            total_score += points

            description = registry_entry["description"]
            if evidence:
                description = f"{description} ({evidence})"

            risk_factors.append(ThreatFactor(
                category=registry_entry["category"],
                severity=registry_entry["severity"],
                description=description,
                points=points,
                signal=signal_key,
                evidence=evidence,
            ))

        final_score = min(100, max(0, total_score))
        risk_level = cls.get_risk_level(final_score)

        return RiskCalculationResult(
            risk_score=final_score,
            risk_level=risk_level,
            risk_factors=risk_factors,
        )

    @classmethod
    def evaluate_qr_risk(
        cls,
        payload: str,
        is_url: bool,
        destination_url: Optional[str],
        url_analysis: Optional[Dict[str, Any]],
        message_analysis: Optional[Dict[str, Any]],
        ai_analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Evaluate composite prototype risk for QR code payload, aggregating all security signals."""
        signals: List[SecuritySignal] = []
        base_score = 0

        # Process URL analysis signals if present
        if is_url and url_analysis:
            url_score = url_analysis.get("score_contribution", 0)
            base_score += url_score
            
            raw_signals = url_analysis.get("signals", [])
            for sig in raw_signals:
                if isinstance(sig, dict):
                    signals.append(SecuritySignal(
                        category=sig.get("name", "url_heuristic"),
                        severity=sig.get("severity", "MEDIUM"),
                        description=sig.get("description", "URL heuristic flag"),
                        source="url_engine"
                    ))

        # Process Message analysis signals if present
        if message_analysis and "risk" in message_analysis:
            msg_risk = message_analysis.get("risk", {})
            msg_score = msg_risk.get("risk_score", 0)
            if not is_url:
                base_score += msg_score
            else:
                base_score += int(msg_score * 0.5)

            for factor in msg_risk.get("factors", []):
                if isinstance(factor, dict):
                    signals.append(SecuritySignal(
                        category=factor.get("category", "text_heuristic"),
                        severity=factor.get("severity", "MEDIUM"),
                        description=factor.get("description", "Message text flag"),
                        source="message_engine"
                    ))

        # Process AI analysis signals
        if ai_analysis and ai_analysis.get("ai_analysis_performed"):
            base_score += ai_analysis.get("risk_adjustment", 0)
            for ai_sig in ai_analysis.get("signals", []):
                if isinstance(ai_sig, dict):
                    signals.append(SecuritySignal(
                        category=ai_sig.get("category", "ai_signal"),
                        severity=ai_sig.get("severity", "MEDIUM"),
                        description=ai_sig.get("description", "AI detected anomaly"),
                        source="ai_engine"
                    ))

        # Additional QR-specific checks
        payload_lower = payload.lower() if payload else ""
        if is_url:
            signals.append(SecuritySignal(
                category="qr_url_payload",
                severity="LOW",
                description="QR code resolves to an external URL destination requiring verification",
                source="qr_engine"
            ))
            if any(tld in payload_lower for tld in [".xyz", ".top", ".info", ".tk", ".ml", ".zip"]):
                base_score += 15

        # Calculate final bounded prototype risk score
        final_score = min(100, max(0, base_score))
        risk_level = cls.get_risk_level(final_score)

        # Determine precise attack type classification
        attack_type = "Benign / Safe"
        if is_url:
            if url_analysis and url_analysis.get("possible_typosquatting_indicators"):
                attack_type = "Typosquatting Domain Spoofing"
            elif url_analysis and url_analysis.get("presence_of_ip_address"):
                attack_type = "Malicious IP Direct Access"
            elif ai_analysis.get("attack_type") and "Credential" in ai_analysis.get("attack_type"):
                attack_type = "Quishing (QR Credential Harvesting)"
            elif risk_level in ["HIGH", "CRITICAL"]:
                attack_type = "Quishing (QR Phishing)"
            elif url_analysis and url_analysis.get("url_shortener_indicators"):
                attack_type = "Suspicious Shortened Link"
            elif risk_level == "MEDIUM":
                attack_type = "Potential Quishing Risk"
        else:
            if ai_analysis.get("attack_type") and "Credential" in ai_analysis.get("attack_type"):
                attack_type = "Plain Text Credential Scam"
            elif "wifi:" in payload_lower:
                attack_type = "Wi-Fi Configuration Trap"
            elif risk_level in ["HIGH", "CRITICAL"]:
                attack_type = "Social Engineering Scam"
            elif risk_level == "MEDIUM":
                attack_type = "Suspicious Plain Text Payload"

        # Formulate human-explainable explanation using prototype risk score language
        explanation_parts = []
        if is_url:
            explanation_parts.append(f"QR payload resolves to destination URL '{destination_url}'.")
            if url_analysis and url_analysis.get("suspicious"):
                explanation_parts.append("Deterministic URL engine detected security risk heuristics.")
            if risk_level in ["HIGH", "CRITICAL"]:
                explanation_parts.append("Elevated prototype risk score indicates potential QR phishing (Quishing) attempt.")
            elif risk_level == "MEDIUM":
                explanation_parts.append("Moderate risk indicators present in URL structure.")
            else:
                explanation_parts.append("No obvious malicious URL indicators found.")
        else:
            explanation_parts.append("QR payload contains plain text content.")
            if risk_level in ["HIGH", "CRITICAL"]:
                explanation_parts.append("Text payload contains high-pressure social engineering or credential request indicators.")
            elif risk_level == "MEDIUM":
                explanation_parts.append("Text payload contains potential security signals requiring review.")
            else:
                explanation_parts.append("Plain text payload appears benign.")

        if ai_analysis and ai_analysis.get("ai_explanation"):
            explanation_parts.append(ai_analysis["ai_explanation"])

        explanation = " ".join(explanation_parts)

        # Formulate recommended action advice
        if risk_level == "CRITICAL":
            recommended_action = "CRITICAL WARNING: Do NOT visit the destination URL or follow instructions. Do NOT enter credentials or personal data. Report QR code to security administrators."
        elif risk_level == "HIGH":
            recommended_action = "HIGH RISK: Do NOT open or execute the destination automatically. Verify the sender/source out-of-band through trusted official channels."
        elif risk_level == "MEDIUM":
            recommended_action = "MODERATE RISK: Inspect destination domain carefully. Ensure scheme and domain match expected official sites before interacting."
        else:
            recommended_action = "LOW RISK: No significant malicious indicators detected. Maintain standard security awareness."

        # Build backwards compatible RiskDetails object
        risk_factors_list = [
            ThreatFactor(category=s.category, severity=s.severity, description=s.description)
            for s in signals
        ]
        risk_details = RiskDetails(
            risk_score=final_score,
            risk_level=risk_level,
            summary=explanation,
            risk_factors=risk_factors_list,
            factors=risk_factors_list,
            recommended_action=recommended_action,
            extracted_urls=[destination_url] if destination_url else []
        )

        return {
            "risk_score": final_score,
            "risk_level": risk_level,
            "attack_type": attack_type,
            "security_signals": signals,
            "explanation": explanation,
            "recommended_action": recommended_action,
            "risk": risk_details
        }
