"""Deterministic URL Security Engine for Iron Defense.

Parses and analyzes URLs without LLM assistance, extracting structural properties
and detecting security risk heuristics (IP addresses, typosquatting, domain mismatches,
suspicious TLDs, URL shorteners, etc.).
"""

import re
import urllib.parse
import ipaddress
from typing import Dict, List, Any, Optional, Set, Tuple
from pydantic import BaseModel, Field

# Multi-level TLD suffixes for accurate registered domain parsing
MULTI_PART_TLDS: Set[str] = {
    "co.uk", "org.uk", "me.uk", "net.uk", "gov.uk", "ac.uk",
    "com.au", "net.au", "org.au", "edu.au", "gov.au",
    "co.in", "net.in", "org.in", "gen.in", "ind.in", "firm.in",
    "com.br", "net.br", "gov.br", "org.br",
    "co.jp", "ne.jp", "or.jp", "go.jp",
    "com.cn", "net.cn", "org.cn", "gov.cn",
    "co.nz", "net.nz", "org.nz",
    "com.sg", "edu.sg", "gov.sg",
    "co.za", "web.za", "org.za",
    "com.mx", "gob.mx",
    "co.kr", "ne.kr", "or.kr",
    "com.tw", "org.tw",
    "com.tr", "edu.tr",
    "co.ca", "gc.ca",
    "edu.us", "gov.us",
    "com.de", "co.at"
}

# Suspicious TLDs commonly seen in malicious/phishing campaigns
SUSPICIOUS_TLDS: Set[str] = {
    ".xyz", ".top", ".info", ".tk", ".ml", ".cf", ".gq", ".zip", ".mov",
    ".work", ".click", ".link", ".live", ".loan", ".buzz", ".online",
    ".site", ".club", ".casa", ".surf", ".icu", ".rest", ".fit", ".kim",
    ".racing", ".country", ".download", ".stream", ".bid", ".review"
}

# Known URL Shorteners
URL_SHORTENERS: Set[str] = {
    "bit.ly", "tinyurl.com", "t.co", "cutt.ly", "is.gd", "goo.gl",
    "ow.ly", "rb.gy", "shorturl.at", "tiny.cc", "bc.vc", "v.gd",
    "qr.ae", "adf.ly", "bit.do", "lnkd.in", "db.tt", "tr.im", "s.id",
    "clck.ru", "shorte.st", "po.st"
}

# Major legitimate targeted brand domains for typosquatting / mismatch checks
TARGET_BRAND_DOMAINS: Set[str] = {
    "google.com", "paypal.com", "microsoft.com", "apple.com", "amazon.com",
    "netflix.com", "facebook.com", "instagram.com", "github.com", "chase.com",
    "wellsfargo.com", "binance.com", "coinbase.com", "linkedin.com", "twitter.com",
    "dropbox.com", "stripe.com", "bankofamerica.com", "docusign.com", "walmart.com",
    "steamcommunity.com", "spotify.com"
}

BRAND_KEYWORDS: Set[str] = {
    "paypal", "google", "microsoft", "apple", "amazon", "netflix", "facebook",
    "instagram", "github", "chase", "wellsfargo", "binance", "coinbase",
    "linkedin", "twitter", "dropbox", "stripe", "bankofamerica", "docusign",
    "walmart", "steam", "spotify", "outlook", "office365", "icloud"
}

# Homoglyphs / lookalike substitution mappings
HOMOGLYPH_MAP = {
    '0': 'o', '1': 'l', '!': 'i', '3': 'e', '4': 'a', '@': 'a',
    '5': 's', '$': 's', '7': 't', '8': 'b', 'vv': 'w'
}

class URLSignal(BaseModel):
    name: str = Field(..., description="Name of the detected heuristic signal")
    description: str = Field(..., description="Detailed explanation of signal")
    severity: str = Field(..., description="Severity level: LOW, MEDIUM, HIGH, CRITICAL")
    score: int = Field(..., description="Score contribution")

class URLAnalysisResult(BaseModel):
    url: str
    scheme: str = ""
    hostname: str = ""
    registered_domain: str = ""
    port: Optional[int] = None
    path: str = "/"
    query_parameters: Dict[str, Any] = Field(default_factory=dict)
    subdomain_count: int = 0
    url_length: int = 0
    presence_of_ip_address: bool = False
    suspicious_characters: bool = False
    url_encoding: bool = False
    excessive_subdomains: bool = False
    suspicious_tld: bool = False
    url_shortener_indicators: bool = False
    hostname_domain_mismatch_indicators: bool = False
    possible_typosquatting_indicators: bool = False
    signals: List[URLSignal] = Field(default_factory=list)
    suspicious: bool = False
    score_contribution: int = 0

def levenshtein_distance(s1: str, s2: str) -> int:
    """Calculate Levenshtein distance between two strings."""
    if len(s1) < len(s2):
        return levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)
    previous_row = list(range(len(s2) + 1))
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row
    return previous_row[-1]

def normalize_lookalikes(text: str) -> str:
    """Normalize common visual lookalikes/homoglyphs for typosquatting checks."""
    res = text.lower()
    for k, v in HOMOGLYPH_MAP.items():
        res = res.replace(k, v)
    return res

class URLEngine:
    """Deterministic URL Security Analysis Engine."""

    @staticmethod
    def extract_registered_domain(hostname: str) -> Tuple[str, List[str]]:
        """Extract registered domain and subdomain list from hostname."""
        if not hostname:
            return "", []
        
        # Check if hostname is IP address
        if URLEngine.is_ip_address(hostname):
            return hostname, []
            
        labels = hostname.lower().split('.')
        if len(labels) <= 1:
            return hostname, []
        if len(labels) == 2:
            return hostname, []

        # Check multi-part TLD (e.g. co.uk)
        last_two_tld = f"{labels[-2]}.{labels[-1]}"
        if last_two_tld in MULTI_PART_TLDS:
            if len(labels) >= 3:
                reg_domain = ".".join(labels[-3:])
                subdomains = labels[:-3]
            else:
                reg_domain = hostname
                subdomains = []
        else:
            reg_domain = ".".join(labels[-2:])
            subdomains = labels[:-2]
            
        return reg_domain, subdomains

    @staticmethod
    def is_ip_address(hostname: str) -> bool:
        """Check if hostname is IPv4 or IPv6 address (including hex/octal representations)."""
        if not hostname:
            return False
        cleaned = hostname.strip("[]").lower()
        try:
            ipaddress.ip_address(cleaned)
            return True
        except ValueError:
            pass
            
        # Check octal / hex / integer 4-octet IPv4 notation
        parts = cleaned.split('.')
        if len(parts) == 4:
            try:
                for p in parts:
                    if p.startswith(('0x', '0X')):
                        int(p, 16)
                    elif p.startswith('0') and len(p) > 1:
                        int(p, 8)
                    else:
                        val = int(p, 10)
                        if val < 0 or val > 255:
                            return False
                return True
            except ValueError:
                pass
        return False

    @staticmethod
    def detect_suspicious_characters(url: str, netloc: str, path: str) -> bool:
        """Check for suspicious characters such as @, non-ASCII, zero-width space, or abnormal slashes."""
        if '@' in netloc:
            return True
        if '//' in path:
            return True
        # Check non-ASCII
        try:
            url.encode('ascii')
        except UnicodeEncodeError:
            return True
        # Check zero-width space characters or hex control chars
        suspicious_chars = {'\u200b', '\u200c', '\u200d', '\ufeff', '\x00', '\r', '\n'}
        if any(c in url for c in suspicious_chars):
            return True
        return False

    @staticmethod
    def detect_url_encoding_anomalies(url: str, path: str, query: str) -> bool:
        """Detect double encoding, excessive percent encoding, or encoded alphanumeric chars."""
        # Double encoding check e.g. %252f or %2520
        if re.search(r'%25[0-9a-fA-F]{2}', url):
            return True
        # Encoded alphanumerics (e.g. %61 for 'a', %41 for 'A')
        if re.search(r'%(?:4[1-9a-fA-F]|5[0-9aA]|6[1-9a-fA-F]|7[0-9aA])', url):
            return True
        # Excessive percent encoding ratio (>15% of path+query length)
        combined = path + query
        if len(combined) > 10:
            encoded_count = len(re.findall(r'%[0-9a-fA-F]{2}', combined)) * 3
            if (encoded_count / len(combined)) > 0.15:
                return True
        return False

    @staticmethod
    def detect_hostname_mismatch(
        scheme: str, hostname: str, registered_domain: str, path: str, netloc: str, port: Optional[int]
    ) -> bool:
        """Detect domain mismatch indicators like brand name in subdomain/path or HTTP sensitive logins."""
        # @ authority trick
        if '@' in netloc:
            return True
        
        # Sensitive action keywords
        sensitive_keywords = {'login', 'verify', 'account', 'bank', 'signin', 'secure', 'password', 'checkout', 'credential'}
        has_sensitive_path = any(kw in path.lower() for kw in sensitive_keywords)

        # HTTP sensitive path check
        if scheme == 'http' and has_sensitive_path:
            return True

        # Non-standard port check with sensitive path
        if port and port not in (80, 443) and has_sensitive_path:
            return True

        # Brand keyword in subdomain or path while registered domain is NOT that brand
        reg_domain_name = registered_domain.split('.')[0] if registered_domain else ""
        for brand in BRAND_KEYWORDS:
            if brand != reg_domain_name:
                # Check if brand is in subdomain or path
                if brand in hostname and brand not in registered_domain:
                    return True
                if f"/{brand}" in path.lower() or f"{brand}.com" in path.lower():
                    return True
                    
        return False

    @staticmethod
    def detect_typosquatting(registered_domain: str) -> Tuple[bool, Optional[str]]:
        """Detect typosquatting indicators against popular target brand domains."""
        if not registered_domain or URLEngine.is_ip_address(registered_domain):
            return False, None
            
        reg_lower = registered_domain.lower()
        if reg_lower in TARGET_BRAND_DOMAINS:
            return False, None

        # Check normalization lookalikes
        normalized = normalize_lookalikes(reg_lower)
        for target in TARGET_BRAND_DOMAINS:
            if normalized == target:
                return True, target

        # Check Levenshtein edit distance 1 or 2
        for target in TARGET_BRAND_DOMAINS:
            target_name = target.split('.')[0]
            reg_name = reg_lower.split('.')[0]
            
            if abs(len(reg_name) - len(target_name)) <= 2:
                dist = levenshtein_distance(reg_name, target_name)
                if 1 <= dist <= 2 and len(reg_name) >= 4:
                    return True, target
                    
        return False, None

    @classmethod
    def analyze_url(cls, url: str) -> Dict[str, Any]:
        """Analyze a URL deterministically and return structured analysis result dictionary."""
        url_str = (url or "").strip()
        if not url_str:
            res = URLAnalysisResult(url=url_str)
            return res.model_dump()

        # Parse scheme and netloc
        parsed = urllib.parse.urlparse(url_str)
        if not parsed.scheme and not parsed.netloc:
            # Missing scheme
            parsed = urllib.parse.urlparse("http://" + url_str)
            scheme = ""
        else:
            scheme = parsed.scheme.lower()

        hostname = (parsed.hostname or "").lower()
        port = parsed.port
        path = parsed.path or "/"
        query_str = parsed.query or ""
        
        # Parse query parameters dictionary
        raw_query = urllib.parse.parse_qs(query_str)
        query_parameters = {k: v[0] if len(v) == 1 else v for k, v in raw_query.items()}

        # Registered domain and subdomain count
        registered_domain, subdomains = cls.extract_registered_domain(hostname)
        subdomain_count = len(subdomains)
        url_length = len(url_str)

        # Detect heuristics
        presence_of_ip = cls.is_ip_address(hostname)
        suspicious_chars = cls.detect_suspicious_characters(url_str, parsed.netloc, path)
        url_encoding = cls.detect_url_encoding_anomalies(url_str, path, query_str)
        excessive_subdomains = subdomain_count >= 3
        
        reg_tld = f".{registered_domain.split('.')[-1]}" if '.' in registered_domain else ""
        suspicious_tld = reg_tld in SUSPICIOUS_TLDS or any(registered_domain.endswith(tld) for tld in SUSPICIOUS_TLDS)
        
        url_shortener = (
            registered_domain in URL_SHORTENERS or
            hostname in URL_SHORTENERS or
            any(s in hostname for s in URL_SHORTENERS)
        )
        
        hostname_mismatch = cls.detect_hostname_mismatch(scheme, hostname, registered_domain, path, parsed.netloc, port)
        is_typosquatting, matched_target = cls.detect_typosquatting(registered_domain)

        # Build signals list
        signals: List[URLSignal] = []
        total_score = 0

        if presence_of_ip:
            score = 35
            total_score += score
            signals.append(URLSignal(
                name="presence_of_ip_address",
                description=f"Hostname is an IP address ({hostname}) instead of a domain name",
                severity="HIGH",
                score=score
            ))

        if suspicious_chars:
            score = 20
            total_score += score
            signals.append(URLSignal(
                name="suspicious_characters",
                description="URL contains suspicious characters (e.g. '@', non-ASCII, zero-width space, double slashes)",
                severity="MEDIUM",
                score=score
            ))

        if url_encoding:
            score = 15
            total_score += score
            signals.append(URLSignal(
                name="url_encoding",
                description="URL contains obfuscated or double percent-encoding anomalies",
                severity="LOW",
                score=score
            ))

        if excessive_subdomains:
            score = 15
            total_score += score
            signals.append(URLSignal(
                name="excessive_subdomains",
                description=f"URL contains excessive subdomains ({subdomain_count} subdomains)",
                severity="LOW",
                score=score
            ))

        if suspicious_tld:
            score = 25
            total_score += score
            signals.append(URLSignal(
                name="suspicious_tld",
                description=f"Registered domain uses a high-risk TLD ({reg_tld})",
                severity="MEDIUM",
                score=score
            ))

        if url_shortener:
            score = 20
            total_score += score
            signals.append(URLSignal(
                name="url_shortener_indicators",
                description=f"URL uses a known shortener service ({registered_domain or hostname})",
                severity="MEDIUM",
                score=score
            ))

        if hostname_mismatch:
            score = 30
            total_score += score
            signals.append(URLSignal(
                name="hostname_domain_mismatch_indicators",
                description="Hostname/domain mismatch or unencrypted sensitive authentication path detected",
                severity="HIGH",
                score=score
            ))

        if is_typosquatting:
            score = 35
            total_score += score
            target_desc = f" (target: {matched_target})" if matched_target else ""
            signals.append(URLSignal(
                name="possible_typosquatting_indicators",
                description=f"Domain '{registered_domain}' shows typosquatting indicators against known brands{target_desc}",
                severity="HIGH",
                score=score
            ))

        if url_length > 80:
            score = 10
            total_score += score
            signals.append(URLSignal(
                name="excessive_url_length",
                description=f"URL length is abnormally long ({url_length} characters)",
                severity="LOW",
                score=score
            ))

        # Enforce rule: "Do not declare a URL malicious solely because one heuristic is present."
        # Requires at least 2 distinct heuristic signals AND total score >= 40 to mark suspicious.
        score_contribution = min(100, total_score)
        suspicious = (len(signals) >= 2) and (score_contribution >= 40)

        result = URLAnalysisResult(
            url=url_str,
            scheme=scheme,
            hostname=hostname,
            registered_domain=registered_domain,
            port=port,
            path=path,
            query_parameters=query_parameters,
            subdomain_count=subdomain_count,
            url_length=url_length,
            presence_of_ip_address=presence_of_ip,
            suspicious_characters=suspicious_chars,
            url_encoding=url_encoding,
            excessive_subdomains=excessive_subdomains,
            suspicious_tld=suspicious_tld,
            url_shortener_indicators=url_shortener,
            hostname_domain_mismatch_indicators=hostname_mismatch,
            possible_typosquatting_indicators=is_typosquatting,
            signals=signals,
            suspicious=suspicious,
            score_contribution=score_contribution
        )

        return result.model_dump()
