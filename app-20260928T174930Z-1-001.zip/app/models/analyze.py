from typing import List, Optional
from pydantic import BaseModel, Field


class AnalyzeMessageRequest(BaseModel):
    text: str = Field(..., description="Message text or notification payload to analyze", min_length=1)
    sender: Optional[str] = Field(None, description="Optional sender name or phone number")
    channel: Optional[str] = Field("manual", description="Source channel: sms, notification, manual")


class ThreatFactor(BaseModel):
    category: str = Field(..., description="Category or title of threat signal e.g., Suspicious URL, Urgency")
    severity: str = Field(..., description="Severity level: LOW, MEDIUM, HIGH, CRITICAL")
    description: str = Field(..., description="Human-explainable reason for flag")
    points: int = Field(0, description="Points added by this signal in the risk engine")
    signal: Optional[str] = Field(None, description="Signal key e.g., suspicious_url, credential_request")
    evidence: Optional[str] = Field(None, description="Supporting evidence string")


class RiskDetails(BaseModel):
    risk_score: int = Field(..., ge=0, le=100, description="Calculated prototype risk score (0-100)")
    risk_level: str = Field(..., description="Categorical risk level: LOW, MEDIUM, HIGH, CRITICAL")
    summary: str = Field(..., description="Explainable summary of the analysis")
    risk_factors: List[ThreatFactor] = Field(default_factory=list, description="Transparent risk factor breakdown")
    factors: List[ThreatFactor] = Field(default_factory=list, description="Alias for risk_factors for backward compatibility")
    recommended_action: str = Field(..., description="Clear advice for the user")
    extracted_urls: List[str] = Field(default_factory=list, description="URLs identified in the message")


class AnalyzeMessageResponse(BaseModel):
    success: bool = True
    analyzed_at: str = Field(..., description="ISO 8601 timestamp of analysis")
    risk: RiskDetails
    analysis_source: str = Field("risk_engine", description="Source engine used for analysis")


class SecuritySignal(BaseModel):
    category: str = Field(..., description="Category of signal e.g. typosquatting, urgency, ip_address")
    severity: str = Field(..., description="Severity level: LOW, MEDIUM, HIGH, CRITICAL")
    description: str = Field(..., description="Human-readable explanation of signal")
    source: str = Field("rule_engine", description="Source of signal: url_engine, message_engine, ai_engine, qr_engine")


class AnalyzeQRRequest(BaseModel):
    image_base64: Optional[str] = Field(None, description="Base64 encoded QR code image")
    qr_text: Optional[str] = Field(None, description="Direct QR string payload for testing")


class AnalyzeQRResponse(BaseModel):
    success: bool = True
    analyzed_at: str = Field(..., description="ISO 8601 timestamp of analysis")
    qr_payload: str = Field(..., description="Raw extracted QR string payload")
    is_url: bool = Field(..., description="Whether extracted payload is a URL")
    destination_url: Optional[str] = Field(None, description="Extracted destination URL if payload is URL")
    security_signals: List[SecuritySignal] = Field(default_factory=list, description="All security signals detected")
    risk_score: int = Field(..., ge=0, le=100, description="Composite risk score 0-100")
    risk_level: str = Field(..., description="Risk level: SAFE, LOW, MEDIUM, HIGH, CRITICAL")
    attack_type: str = Field(..., description="Categorized attack type e.g. Quishing, Credential Harvesting, Benign / Safe")
    explanation: str = Field(..., description="Detailed explainable analysis summary")
    recommended_action: str = Field(..., description="Clear advisory instructions for the user")
    ai_analysis_performed: bool = Field(False, description="Whether AI analysis was performed")
    analysis_source: str = Field("qr_threat_engine", description="Engine source for QR analysis")
    risk: Optional[RiskDetails] = Field(None, description="Backwards compatible risk details object")


class AnalyzeUrlRequest(BaseModel):
    url: str = Field(..., description="URL string to analyze", min_length=1)


class OCRResult(BaseModel):
    extracted_text: str = Field("", description="Full text extracted from image via OCR")
    extracted_urls: List[str] = Field(default_factory=list, description="URLs extracted from image text")
    ocr_confidence: float = Field(0.0, ge=0.0, le=1.0, description="Confidence score of OCR extraction (0.0 to 1.0)")
    ocr_incomplete: bool = Field(False, description="True if OCR confidence is low or text extraction was incomplete")
    ocr_warning: Optional[str] = Field(None, description="Explanation or warning when OCR extraction is low confidence or incomplete")
    text: Optional[str] = Field(None, description="Alias for extracted_text for backwards compatibility")
    confidence: Optional[float] = Field(None, description="Alias for ocr_confidence for backwards compatibility")

    def model_post_init(self, __context):
        if self.text is None:
            self.text = self.extracted_text
        if self.confidence is None:
            self.confidence = self.ocr_confidence


class AnalyzeScreenshotResponse(BaseModel):
    success: bool = True
    analyzed_at: str = Field(..., description="ISO 8601 timestamp of analysis")
    ocr: OCRResult = Field(..., description="OCR extraction details")
    extracted_text: Optional[str] = Field(None, description="Top-level alias for extracted text")
    risk: RiskDetails
    analysis_source: str = Field("ocr_threat_engine", description="Source engine used for analysis")

    def model_post_init(self, __context):
        if self.extracted_text is None and self.ocr:
            self.extracted_text = self.ocr.extracted_text
