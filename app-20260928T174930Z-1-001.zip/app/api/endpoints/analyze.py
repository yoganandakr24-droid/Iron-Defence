from typing import Optional
from fastapi import APIRouter, HTTPException, Query, UploadFile, File, Form
from app.models.analyze import (
    AnalyzeMessageRequest,
    AnalyzeMessageResponse,
    AnalyzeUrlRequest,
    AnalyzeScreenshotResponse,
)
from app.engines.message_engine import MessageEngine
from app.engines.url_engine import URLEngine
from app.engines.ocr_engine import OCREngine

router = APIRouter()

@router.post("/analyze/message", response_model=AnalyzeMessageResponse, summary="Analyze raw message or SMS for threats")
@router.post("/analyze", response_model=AnalyzeMessageResponse, summary="Analyze raw message or SMS for threats (alias)")
async def analyze_message(request: AnalyzeMessageRequest):
    try:
        if not request.text or not request.text.strip():
            raise HTTPException(status_code=400, detail="Message text cannot be empty")
        
        response = MessageEngine.analyze(request)
        return response
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis engine error: {str(e)}")

@router.post("/analyze/url", summary="Analyze a URL deterministically for security threats")
async def analyze_url_post(request: AnalyzeUrlRequest):
    try:
        if not request.url or not request.url.strip():
            raise HTTPException(status_code=400, detail="URL cannot be empty")
        return URLEngine.analyze_url(request.url)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"URL engine error: {str(e)}")

@router.get("/analyze/url", summary="Analyze a URL deterministically for security threats (GET)")
async def analyze_url_get(url: str = Query(..., min_length=1, description="URL string to analyze")):
    try:
        if not url or not url.strip():
            raise HTTPException(status_code=400, detail="URL query parameter cannot be empty")
        return URLEngine.analyze_url(url)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"URL engine error: {str(e)}")

@router.post("/analyze/screenshot", response_model=AnalyzeScreenshotResponse, summary="Analyze screenshot image (PNG/JPG/JPEG) via OCR and Threat Engine")
async def analyze_screenshot(
    file: UploadFile = File(...),
    sender: Optional[str] = Form(None),
):
    try:
        if not file or not file.filename:
            raise HTTPException(status_code=400, detail="No screenshot file uploaded")

        file_bytes = await file.read()
        if not file_bytes:
            raise HTTPException(status_code=400, detail="Uploaded screenshot file is empty")

        response = OCREngine.process_screenshot(
            file_bytes=file_bytes,
            filename=file.filename,
            sender=sender,
        )
        return response
    except HTTPException:
        raise
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Screenshot analysis error: {str(e)}")
