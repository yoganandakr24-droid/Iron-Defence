"""QR Code Analysis Endpoints for Iron Defense."""

from typing import Optional
from fastapi import APIRouter, File, UploadFile, Form, HTTPException
from app.models.analyze import AnalyzeQRResponse, AnalyzeQRRequest
from app.engines.qr_engine import QREngine

router = APIRouter()


@router.post(
    "/analyze/qr/upload",
    response_model=AnalyzeQRResponse,
    summary="Analyze QR code from uploaded image file"
)
async def analyze_qr_upload(
    file: UploadFile = File(...),
):
    """Upload a QR code image file for decoding and security analysis."""
    try:
        image_bytes = await file.read()
        if not image_bytes:
            raise HTTPException(status_code=400, detail="Uploaded file is empty.")

        response = QREngine.analyze(image_bytes=image_bytes)
        return response

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"QR Analysis engine failure: {str(e)}")


@router.post(
    "/analyze/qr",
    response_model=AnalyzeQRResponse,
    summary="Analyze QR code from base64 image or raw text payload"
)
async def analyze_qr_json(request: AnalyzeQRRequest):
    """Analyze a QR code from a base64-encoded image string or a direct text payload.

    Returns structured threat report including:
    - QR payload
    - Destination URL (if URL)
    - Security signals
    - Risk score
    - Attack type
    - Explanation
    - Recommended action
    """
    try:
        if not request.image_base64 and not request.qr_text:
            raise HTTPException(
                status_code=400,
                detail="Provide either 'image_base64' or 'qr_text' for analysis."
            )

        response = QREngine.analyze(
            image_base64=request.image_base64,
            qr_text=request.qr_text,
        )
        return response

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"QR Analysis engine failure: {str(e)}")
