from fastapi import APIRouter
from app.api.endpoints import health, analyze, qr

api_router = APIRouter()
api_router.include_router(health.router, tags=["System"])
api_router.include_router(analyze.router, tags=["Threat Analysis"])
api_router.include_router(qr.router, tags=["QR Code Analysis"])
